export type Booking = {
  id: number
  full_name: string | null
  hotel: string | null
  room_type: string | null
  checkin: string | null
  checkout: string | null
  amount: number | null
  companion: string | null
  status: "paid" | "pending" | "cancelled" | "waitlisted" | "hosted"
  email: string | null
  mobile: string | null
  guests: number | null
  created_at: string
  // Billing fields
  billing_type: "receipt" | "invoice" | null
  receipt_vat: string | null
  receipt_tax_office: string | null
  company_name: string | null
  vat: string | null
  tax_office: string | null
  company_phone: string | null
  company_address: string | null
  company_email: string | null
  company_activity: string | null
}

export type Allotment = {
  id: number
  hotel: string
  room_type: string
  total_allotment: number
  confirmed_bookings: number
  price_per_night: number
  deadline: string
}

export type AvailabilityRow = {
  hotel: string
  room_type: string
  total_allotment: number
  booked_count: number
  available: number
}

export type Change = {
  id: number
  change_id: string
  booking_id: string
  guest_name: string
  hotel: string
  changed_by: string
  changed_at: string
  change_description: string
  old_value: string
  new_value: string
  amount_delta: number
  requires_payment: string
  requires_refund: string
}
